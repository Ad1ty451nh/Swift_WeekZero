import Foundation

// Enum is the same as Struct except we know all cases at runtime

struct CarModel {
    let brand: CarBrandOption
    let Model: String
}

struct CarBrand {
    let title: String
}


// Enums are storede  in memrory  the same way as the struct but the only difference is you can't Mutate them
enum CarBrandOption{
    case Ford, Toyota, Honda

    
    var title : String{
        switch self{
        case .Ford:
            return "Ford"
        case .Toyota:
            return "Toyota"
        case .Honda:
            return "Honda"
            
//        default:
//            return "Default"
//
        }
    }
//    Using Nested If
//    var title: String{
//        if self == .Ford{
//            return "Ford"
//        } else {
//            return "Toyota"
//        }else {
//            return "Honda"
//        }
//    }
}

//var brand1 = CarBrand(title: "Ford")
//var brand2 = CarBrand(title: "Toyota")
//
//var car1 = CarModel(brand: brand1, Model: "Fiesta")
//var car2 = CarModel(brand: brand1, Model: "Focus")
//var car3 = CarModel(brand: brand2, Model: "Supra")


var car1 = CarModel(brand: .Ford, Model: "Fiesta")

var car2 = CarModel(brand: .Toyota, Model: "Supra")

var FordBrand: CarBrandOption = .Ford

print(FordBrand.title)

import UIKit

let someconstant: Bool = true

var somevariable:  Bool = true

// someConstant = false  / can't assign values as its a constant

somevariable = false

var mynumber:Double = 1.2334

print(mynumber)

mynumber = 23

print(mynumber)

mynumber = 1234565432

print(mynumber)

//If Statements

var userIspremium:Bool = false

if userIspremium == true{
    print("1 - user is premium")
} else{
    print("User is not premium")
}

if userIspremium
{
    print("2- user is premium")
}

if userIspremium == false{
    print("3-User is not Premium")
}

if !userIspremium{
    print("4- User is not premium")
}

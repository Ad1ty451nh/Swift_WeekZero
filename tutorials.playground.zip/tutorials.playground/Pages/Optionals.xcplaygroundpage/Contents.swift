import Foundation




let myBool: Bool = false


var myOtherBool:Bool? = nil

print(myOtherBool)
myOtherBool = true
print(myOtherBool)
myOtherBool = false
print(myOtherBool)
myOtherBool = nil
print(myOtherBool)

//---------------

var userIsNew:Bool? = true
var userDidCompleteOnBoarding:Bool? =false
var UserFavMovie:String? = nil

func CheckIfUserIsSetUp(){
    if let isNew = userIsNew,let DidCompleteOnBoarding = userDidCompleteOnBoarding let FavMovie = UserFavMovie{
        // userIsNew == Bool AND
        // userDidCompleteOnBoarding == Bool AND
        // UserFavMovie == String
        
        return getUserStatus(userIsNew: isNew, userDidCompleteOnBoarding: DidCompleteOnBoarding, UserFavMovie: FavMovie)
    }
}


func getUserStatus(userIsNew : Bool,userDidCompleteOnBoarding:Bool,UserFavMovie:String)-> Bool{
    if userIsNew && userDidCompleteOnBoarding{
        return true
    }
    return false
}

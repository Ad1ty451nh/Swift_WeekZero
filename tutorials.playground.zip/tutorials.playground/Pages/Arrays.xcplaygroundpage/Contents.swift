import Foundation

// Arrays, Sets

var fruitsArray : [String] = ["Apple","Orange","Banana","Mango"]

let count = fruitsArray.count

let firstItem = fruitsArray.first
let lastItem = fruitsArray.last

if let firstItem = fruitsArray.first {
    
}

//fruitsArray = fruitsArray + ["Watermelon"]

fruitsArray.append("Watermelon")
fruitsArray.append("Cherry")

fruitsArray.append(contentsOf: ["Grapes","Coconut"])

print(fruitsArray)

let firstIndex = fruitsArray.indices.first
let lastIndex = fruitsArray.indices.last

//print(firstIndex)
//print(lastIndex)

fruitsArray.insert("Guava", at: 4)

fruitsArray.remove(at: 7)

print(fruitsArray)



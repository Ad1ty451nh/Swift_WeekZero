import UIKit

var likeCount : Double = 5

var commentCount: Double = 1

var viewCount:Double = 100

//Addition
//likeCount = likeCount + 1
//likeCount += 1

//Substraction
//likeCount = likeCount - 1
//likeCount -= 1

//Multiplication
//likeCount = likeCount * 1.5
//likeCount *= 1.5

//Division
//likeCount = likeCount / 2
//likeCount /= 2


//Order of operations matter!
////PEMDAS
//likeCount = (likeCount - 1) * 1.5
//likeCount = likeCount - 1 * 1.5

likeCount += 1

if likeCount == 5 {
    print("post has 5 likes")
}else{
    print("Post does not have 5 likes")
}

if likeCount != 5{
    print("Post dont have 5 likes")
}

if likeCount > 5 {
    print("Greater than 5 likes")
}

if (likeCount > 3) && (commentCount > 0){
    print("more than 5 likes and more than 0 comments")
} else{
    print(" has 3 or less likes and 0 comments")
}

if likeCount > 3 || commentCount > 0
{
    print("more than 5 likes and more than 0 comments")
}else{
    print("has 3 or less likes and 0 comments")
}

if (likeCount > 3 && commentCount > 0) || viewCount > 50 {
    print("Execute")
}

if likeCount > 5{
    print("like count > 5")
} else if likeCount > 2 {
    print("likes > 2")
} 

// Classes are slow
// Classes are stored in Heap (Memory)
// Objects in the heap are Reference types
// Reference types point to an object in memory and update the object in memory

import Foundation

class ScreenViewModel {
    let title: String
    var showButton: Bool
    
    init(title: String, showButton: Bool) {
        self.title = title
        self.showButton = showButton
    }
    
    
    deinit {
        // runs as the object is being removed from memory
        // Struct do not have deinit!
    }
    
}

let viewModel: ScreenViewModel = ScreenViewModel(title: "Title 1", showButton: true)

viewModel.showButton = false



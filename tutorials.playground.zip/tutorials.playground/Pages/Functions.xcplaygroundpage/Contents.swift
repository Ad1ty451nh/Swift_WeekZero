import Foundation

func myFirstFunction(){
    print("My First Function Called")
    mySecondFunction()
    
}

func mySecondFunction(){
    print("My Second Function Called")
}

myFirstFunction()

func getUsername() -> String{
    let username:String = "DevManush"
    return username
}

let name:String = getUsername()
print(name)

// -----------------

showFirstScreen()

func showFirstScreen(){
    var userDidCompleteOnboarding : Bool = false
    var userProfileIsCreated:Bool = true
    checkUserStatus(didCompleteOnBoarding: userDidCompleteOnboarding, profileIsCreated: userProfileIsCreated)
    let status =  checkUserStatus(didCompleteOnBoarding: userDidCompleteOnboarding, profileIsCreated: userProfileIsCreated)
    
    if status == true {
        print("Show Home Screen")
    }else {
        print("Show Onboarding Screen")
    }
}

func checkUserStatus(didCompleteOnBoarding:Bool,profileIsCreated:Bool)-> Bool {
    if didCompleteOnBoarding && profileIsCreated {
        return true
    }else {
        return false
    }
}

func doSomethingElse(someValue: Bool){
    
}

func doSomething()-> String{
    var title: String = "Avengers"
    
    if title == "Avengers"{
        return "Marvel"
    }
    return "Marvel"
}
//
//
//func getUsername()-> String{
//    return "test"
//}
//
//func getUserData()-> String{
//    return "title"
//}
//


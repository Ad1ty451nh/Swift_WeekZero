import Foundation

var finalFruits: [String] = ["Apple","Orange","Banana","Apple"]

print(finalFruits)

//let item = finalFruits[1]

var fruitSet: Set<String> = ["Apple","Orange","Banana","Apple"]

print(fruitSet)


var myFirstDictionary : [String:Bool] = ["Apple": true, "Banana": false,"Orange":true]

let item = myFirstDictionary["Orange"]


var anotherDictionary : [Int:String] = [
    123 : "Apple",
    69 : "Banana",
    88 : "Orange"
]

let item2 = anotherDictionary[69]

print(item)

print(item2)


struct PostModel {
    let id: String
    let title: String
    let likeCount: Int
}

var postArray: [PostModel] = [
    PostModel(id: "abc123", title: "Post1", likeCount: 354),
    PostModel(id: "bcd356", title: "Post2", likeCount: 896),
    PostModel(id: "xgt923", title: "Post3", likeCount: 653)
]

if postArray.indices.contains(1){
    let item = postArray[1]
    print(item)
}

var postDict: [String:PostModel] = [
    "abc123" : PostModel(id: "abc123", title: "Post1", likeCount: 354),
    "bcd356" : PostModel(id: "bcd356", title: "Post2", likeCount: 896),
    "xgt923" : PostModel(id: "xgt923", title: "Post3", likeCount: 653)
]

let myNewItem = postDict["bcd356"]

print(myNewItem)


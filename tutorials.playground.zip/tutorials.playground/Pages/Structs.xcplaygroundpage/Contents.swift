import Foundation

// --------- Beginner ----------

struct Person{
    let name : String
    
    var age : Int
}

let person1 = Person(name:"Aditya",age: 21)
// person1.age = 22 //Immutable instance so it will give errors.

var person2 = Person(name: "Dev", age: 20)
person2.age = 21

print(person1.age)
print(person2.self)


// -------- Intermediate --------

struct bankAccount{
    var balance: Double
    mutating func Deposit(amount:Double){
        balance += amount
    }
    
    mutating func Withdraw(amount:Double){
        balance -= amount
    }
    
}

var Account1 = bankAccount(balance: 10000)

var Account2 = Account1

Account1.Deposit(amount: 5000)

Account2.Withdraw(amount: 2500)

print(Account1.balance)

print(Account2.balance)


// ------------ Advance ------------

struct Rectangle {
    let width: Double
    let height: Double
    
    var area:Double {
        height * width
    }
    
    mutating func Description() -> String{
       "Width: \(width), Height: \(height), Area: \(area) "
    }
}

var rect1 = Rectangle(width: 50, height: 20)

var rect2 = Rectangle(width: 40, height: 10)

print(rect1.area)

print(rect2.area)

print(rect1.Description())


// --------  Struct with Init --------

struct Book {
    let title: String
    let author: String
    var pages : Int
    
    init(title: String, author: String, pages: Int) {
        self.title = title
        self.author = author
        self.pages = pages
    }
    
    func bookSummary() -> String {
        return "Book: \(title) by \(author) with Pages \(pages)"
    }
}

let Book1 = Book(title: "Few things left unsaid", author: "clover", pages: 250)

print(Book1.bookSummary())

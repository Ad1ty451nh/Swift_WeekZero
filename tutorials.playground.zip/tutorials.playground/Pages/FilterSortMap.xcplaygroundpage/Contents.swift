import Foundation

struct DatabaseUser{
    let name: String
    let isPremium : Bool
    let order : Int
}

var allUsers : [DatabaseUser] = [
    DatabaseUser(name: "Aditya", isPremium: true, order: 10),
    DatabaseUser(name: "Dev", isPremium: false, order: 69),
    DatabaseUser(name: "Nitin", isPremium: false, order: 7),
    DatabaseUser(name: "Shubh", isPremium: true, order: 4),
    DatabaseUser(name: "Vivek", isPremium: true, order: 6)
]
//
//var allPremiumUsers : [DatabaseUser] = allUsers.filter{ user in
//    return user.isPremium
//}
//
//var allPremiumUsers2 : [DatabaseUser] = allUsers.filter({ $0.isPremium })

//    if user.isPremium{
//        return true
//    }
//    return false

//for user in allUsers {
//    if user.isPremium {
//        allPremiumUsers.append(user)
//    }
//}

//print(allPremiumUsers)




var orderedUsers: [DatabaseUser] = allUsers.sorted { user1, user2 in
    return user1.order < user2.order
}

var orderedUsers2: [DatabaseUser] = allUsers.sorted(by: { $0.order < $1.order })

print(orderedUsers)


var userNames : [String] = allUsers.map { user in
    return user.name
}

var userNames2 : [String] = allUsers.map ({ $0.name })

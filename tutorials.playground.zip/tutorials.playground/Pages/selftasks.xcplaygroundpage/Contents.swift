import Foundation

//struct UserProfile{
//    let username: String
//    let birthYear: Int
//    var isPremium: Bool
//    
//    var age: Int{
//        return  2026 - birthYear
//    }
//    
//    mutating func upgradeToPremium() {
//        isPremium = true
//    }
//    
//    func profileSummary() -> String {
//        "Username: \(username),Age: \(age),Premium: \(isPremium)"
//    }
//    
//}
//
//
//var user1 = UserProfile(username: "ADITYASINH", birthYear: 2004, isPremium: true)
//
//print(user1.age)
//
//print(user1.profileSummary())


struct BankAccount{
    let accountHolder : String
    let accountNumber : Int
    var balance : Double
    
    init(accountHolder: String, accountNumber: Int, balance: Double) {
        self.accountHolder = accountHolder
        self.accountNumber = accountNumber
        self.balance = balance
        
        if balance < 0  {
            self.balance = 0
        } else {
            self.balance = balance
        }
    }
    
    mutating func withdraw(amount:Double){
        balance -= amount
    }
    
    mutating func Deposit(amount:Double){
        balance += amount
    }
    
    func accountSummary() ->String{
        "Account Holder: \(accountHolder) Balance: ₹\(balance)"
    }
    
}

var user = BankAccount(accountHolder: "Adityasinh", accountNumber: 123456, balance: 5000)

print(user.accountSummary())

user.withdraw(amount: 500)

print(user.accountSummary())
    
user.Deposit(amount: 1000)

print(user.accountSummary())

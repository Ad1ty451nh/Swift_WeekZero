import Foundation

struct MovieModel{
    let title:String
    let genre:MovieGenre
    let isFavorite: Bool
    
    func updateFavoriteStatus(newValue: Bool) -> MovieModel {
        MovieModel(title: title, genre: genre, isFavorite: newValue)
    }
}

enum MovieGenre{
    case Comedy, Action, Horror
}

class MovieManager{
    
    var movie1 = MovieModel(title: "Lion King", genre: .Comedy, isFavorite: true)
    
    var movie2 = MovieModel(title: "Intersteller", genre: .Action, isFavorite: true)
    
    var movie3 = MovieModel(title: "Annabelle", genre: .Horror, isFavorite: false)
    
}

let manager = MovieManager()

manager.movie1 = manager.movie1.updateFavoriteStatus(newValue: false)
print(manager.movie1)

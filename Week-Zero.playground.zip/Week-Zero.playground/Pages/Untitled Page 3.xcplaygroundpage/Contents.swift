import Foundation


enum CharacterColor{
    case CherryRed
    case SkyBlue
    case OliveGreen
}

struct GameCharacter{
    var name:String
    var clothingColor: CharacterColor
}

var char = GameCharacter(name: "Alex", clothingColor: .CherryRed)

var player = GameCharacter(name: "Aditya", clothingColor: .SkyBlue)

      
@MainActor func describeOutfit(){
    
}
